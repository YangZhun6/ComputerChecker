# ComputerChecker
Exercise caution when purchasing computers that have undergone unauthorized hardware modifications, where incompatible hardware has been installed on platforms that should not support it in principle. This is an open-source project for detecting such hardware alterations.
